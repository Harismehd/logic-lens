/**
 * Logic Lens Advanced Pedagogy Engine
 * Handles Error Mutation and Expert Refactoring
 */

export const getErrorVariants = (errorType, contextCode) => {
    const database = {
        'MISSING_COLON': [
            "def my_func() \n    return 1",
            "if x > 10 \n    print(x)",
            "for i in range(5) \n    pass"
        ],
        'INDENTATION': [
            "def start():\nreturn 0",
            "if True:\n    print(1)\n  print(2)",
            "while False:\npass"
        ],
        'NAME_ERROR': [
            "return total / count # Where total isn't defined",
            "x = y + 1 # Where y isn't defined",
            "print(undefined_variable)"
        ]
    };

    const variants = database[errorType] || [
        "# Fix this syntax error:\n" + contextCode,
        "# Another variant:\n" + contextCode.replace(':', ''),
        "# Final challenge:\n" + contextCode.replace('def', 'def_')
    ];

    return variants.slice(0, 3);
};

export const getRefactorSuggestions = (patternId, userCode) => {
    const suggestions = {
        'calculate_average': [
            {
                type: 'Expert',
                title: 'Using built-in sum() and len()',
                code: "def calculate_average(nums):\n    if not nums: return 0\n    return sum(nums) / len(nums)",
                benefit: "Shorter and more readable using Python's power."
            },
            {
                type: 'Fast',
                title: 'Early Exit Pattern',
                code: "def calculate_average(nums):\n    count = len(nums)\n    if count == 0: return 0\n    return sum(nums) / count",
                benefit: "Avoids redundant length calculations."
            }
        ],
        'find_largest': [
            {
                type: 'Expert',
                title: 'Using built-in max()',
                code: "def find_largest(nums):\n    return max(nums) if nums else None",
                benefit: "Direct and efficient."
            }
        ]
    };

    return suggestions[patternId] || [{
        type: 'General',
        title: 'Better Naming',
        code: userCode.replace(/x|y|i|j/g, 'item'),
        benefit: "Descriptive names improve code maintainability."
    }];
};
