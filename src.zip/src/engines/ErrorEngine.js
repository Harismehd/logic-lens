export const ERROR_TYPES = {
  SYNTAX: 'syntax',
  TYPE: 'type',
  NAME: 'name',
  INDENTATION: 'indentation',
  MISSING_COLON: 'missing_colon',
  RUNTIME: 'runtime',
  WARNING: 'warning',
  HINT: 'hint',
  SUCCESS: 'success'
};

export const COLOR_MAP = {
  [ERROR_TYPES.SYNTAX]: '#FF0000',
  [ERROR_TYPES.TYPE]: '#FF5500',
  [ERROR_TYPES.NAME]: '#FFA500',
  [ERROR_TYPES.INDENTATION]: '#FF00FF',
  [ERROR_TYPES.RUNTIME]: '#FF3333',
  [ERROR_TYPES.WARNING]: '#FFFF00',
  [ERROR_TYPES.HINT]: '#00FFFF',
  [ERROR_TYPES.SUCCESS]: '#00FF88',
  'correct': '#00FF00'
};

export const scanPythonCode = (code) => {
  const lines = code.split('\n');
  const errors = [];

  lines.forEach((line, index) => {
    const lineNumber = index + 1;
    const trimmedLine = line.trim();
    if (trimmedLine.length === 0) return;

    // 1. Indentation Check
    const indentMatch = line.match(/^(\s*)/);
    const indentSize = indentMatch ? indentMatch[1].length : 0;
    if (indentSize > 0 && indentSize % 4 !== 0) {
      errors.push({
        line: lineNumber,
        column: 1,
        endColumn: indentSize + 1,
        type: ERROR_TYPES.INDENTATION,
        message: `Indentation error: Expected 4 spaces, but found ${indentSize}.`
      });
    }

    // 2. Missing Colon (The "Emergency" fix)
    // Check for common block starters
    const blockStarters = [
        { pattern: /^def\s+\w+.*$/, name: 'function definition' },
        { pattern: /^if\s+.*$/, name: 'if statement' },
        { pattern: /^elif\s+.*$/, name: 'elif statement' },
        { pattern: /^else\s*$/, name: 'else statement' },
        { pattern: /^for\s+.*$/, name: 'for loop' },
        { pattern: /^while\s+.*$/, name: 'while loop' },
        { pattern: /^try\s*$/, name: 'try block' },
        { pattern: /^except(\s+.*)?$/, name: 'except block' },
        { pattern: /^class\s+\w+.*$/, name: 'class definition' }
    ];

    for (const starter of blockStarters) {
        if (starter.pattern.test(trimmedLine)) {
            if (!trimmedLine.endsWith(':')) {
                // Point to the end of the line
                errors.push({
                    line: lineNumber,
                    column: line.length || 1,
                    endColumn: line.length + 2,
                    type: ERROR_TYPES.MISSING_COLON,
                    message: `Missing colon (:) at end of ${starter.name}.`
                });
            }
            break;
        }
    }

    // 3. Keyword Typos (e.g., "defin" instead of "def")
    const commonTypos = [
        { typo: /^defin\s+/, correct: 'def' },
        { typo: /^iff\s+/, correct: 'if' },
        { typo: /^fore\s+/, correct: 'for' },
        { typo: /^whille\s+/, correct: 'while' },
        { typo: /^retun\s+/, correct: 'return' }
    ];

    for (const item of commonTypos) {
        if (item.typo.test(trimmedLine)) {
            errors.push({
                line: lineNumber,
                column: line.indexOf(trimmedLine.split(' ')[0]) + 1,
                endColumn: line.indexOf(trimmedLine.split(' ')[0]) + trimmedLine.split(' ')[0].length + 1,
                type: ERROR_TYPES.SYNTAX,
                message: `Possible typo: Did you mean '${item.correct}'?`
            });
        }
    }

    // 4. Mismatched Parentheses/Brackets/Quotes
    const pairs = [
        { open: '(', close: ')', name: 'parentheses' },
        { open: '[', close: ']', name: 'brackets' },
        { open: '{', close: '}', name: 'braces' }
    ];

    pairs.forEach(pair => {
        const opens = (line.match(new RegExp('\\' + pair.open, 'g')) || []).length;
        const closes = (line.match(new RegExp('\\' + pair.close, 'g')) || []).length;
        if (opens > closes) {
            errors.push({
                line: lineNumber,
                column: line.lastIndexOf(pair.open) + 1,
                endColumn: line.lastIndexOf(pair.open) + 2,
                type: ERROR_TYPES.SYNTAX,
                message: `Unclosed ${pair.name}.`
            });
        } else if (closes > opens) {
            errors.push({
                line: lineNumber,
                column: line.indexOf(pair.close) + 1,
                endColumn: line.indexOf(pair.close) + 2,
                type: ERROR_TYPES.SYNTAX,
                message: `Unexpected closing ${pair.name}.`
            });
        }
    });
    // 5. Invalid Assignments & Garbage detection (Catching 'a=.sca')
    const invalidAssignment = line.match(/=\s*(\.[a-zA-Z_]|\d+\.\d+\.|[^a-zA-Z0-9_'"\(\[\{\s\-+*\/])/);
    if (invalidAssignment) {
        errors.push({
            line: lineNumber,
            column: line.indexOf('=') + 1,
            endColumn: line.length + 1,
            type: ERROR_TYPES.SYNTAX,
            message: "Invalid assignment. Expected a value, variable, or expression."
        });
    }

    // 6. Unknown Keywords / Invalid line starts
    const words = trimmedLine.split(/[^a-zA-Z0-9_]/);
    const firstWord = words[0];
    const validKeywords = [
        'def', 'if', 'elif', 'else', 'for', 'while', 'try', 'except', 'finally', 
        'class', 'import', 'from', 'as', 'return', 'yield', 'break', 'continue', 
        'pass', 'raise', 'with', 'assert', 'del', 'global', 'nonlocal', 'lambda', 
        'and', 'or', 'not', 'is', 'in', 'None', 'True', 'False'
    ];
    
    // Simple heuristic: if a line starts with a word that isn't a keyword and isn't an assignment/call
    if (firstWord && !validKeywords.includes(firstWord) && !trimmedLine.includes('=') && !trimmedLine.includes('(') && !trimmedLine.includes('.') && isNaN(firstWord)) {
        // This might be a typo'd keyword or a stray word
        if (firstWord.length > 1) { // Ignore single char variables for now
             errors.push({
                line: lineNumber,
                column: line.indexOf(firstWord) + 1,
                endColumn: line.indexOf(firstWord) + firstWord.length + 1,
                type: ERROR_TYPES.SYNTAX,
                message: `Unrecognized statement or keyword: '${firstWord}'.`
            });
        }
    }

    // 7. Double Operators (Python doesn't have ++ or ===)
    const badOps = [
        { op: '++', msg: "Python does not support '++'. Use '+= 1' instead." },
        { op: '--', msg: "Python does not support '--'. Use '-= 1' instead." },
        { op: '===', msg: "Python uses '==' for equality, not '==='." },
        { op: '!==', msg: "Python uses '!=' for inequality, not '!=='." }
    ];
    for (const bad of badOps) {
        if (line.includes(bad.op)) {
            errors.push({
                line: lineNumber,
                column: line.indexOf(bad.op) + 1,
                endColumn: line.indexOf(bad.op) + bad.op.length + 1,
                type: ERROR_TYPES.SYNTAX,
                message: bad.msg
            });
        }
    }

    // 8. Unclosed Quotes
    const quoteCount = (line.match(/'/g) || []).length;
    const doubleQuoteCount = (line.match(/"/g) || []).length;
    if (quoteCount % 2 !== 0) {
        errors.push({
            line: lineNumber,
            column: line.indexOf("'") + 1,
            endColumn: line.length + 1,
            type: ERROR_TYPES.SYNTAX,
            message: "Unclosed single quote."
        });
    } else if (doubleQuoteCount % 2 !== 0) {
        errors.push({
            line: lineNumber,
            column: line.indexOf('"') + 1,
            endColumn: line.length + 1,
            type: ERROR_TYPES.SYNTAX,
            message: "Unclosed double quote."
        });
    }
  });

  return errors;
};

export const scanJSCode = (code) => {
  // Basic JS scanning
  const errors = [];
  // Use a simple try-catch or regex for now
  try {
    new Function(code);
  } catch (e) {
    errors.push({
      line: 1, // Fallback
      type: ERROR_TYPES.SYNTAX,
      message: e.message
    });
  }
  return errors;
};
