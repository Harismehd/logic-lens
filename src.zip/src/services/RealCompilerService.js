/**
 * Logic Lens Real Python Compiler (via Pyodide)
 * 100% Real Python in Browser
 */

let pyodideInstance = null;

const loadPyodide = async () => {
    if (pyodideInstance) return pyodideInstance;
    
    if (!window.loadPyodide) {
        throw new Error("Python engine is still loading. Please wait 5 seconds and try again.");
    }

    // Load from CDN for maximum stability and speed
    const pyodide = await window.loadPyodide({
        indexURL: "https://cdn.jsdelivr.net/pyodide/v0.25.0/full/"
    });
    
    pyodideInstance = pyodide;
    return pyodide;
};

export const executePython = async (code, params = []) => {
    const pyodide = await loadPyodide();
    
    // Capture stdout
    let stdout = "";
    pyodide.setStdout({
        batched: (text) => { stdout += text + "\n"; }
    });

    try {
        // Execute the user code
        await pyodide.runPythonAsync(code);

        // If it's a function mission, find the function and call it
        const funcNameMatch = code.match(/def\s+(\w+)\(/);
        let returnValue = null;
        
        if (funcNameMatch) {
            const funcName = funcNameMatch[1];
            const pythonFunc = pyodide.globals.get(funcName);
            if (pythonFunc) {
                const rawValue = pythonFunc(...params);
                // Convert PyProxy to JS if necessary
                returnValue = (rawValue && typeof rawValue.toJs === 'function') ? rawValue.toJs() : rawValue;
            }
        }

        return {
            success: true,
            stdout: stdout.trim(),
            returnValue,
            error: null
        };
    } catch (e) {
        // Extract line number from Python traceback
        const lineMatch = e.message.match(/Line (\d+)/i) || e.message.match(/line (\d+)/);
        return {
            success: false,
            stdout: stdout.trim(),
            returnValue: null,
            error: {
                message: e.message,
                line: lineMatch ? parseInt(lineMatch[1]) : null
            }
        };
    }
};

export const runWithTimeout = async (code, params = [], timeoutMs = 5000) => {
    return Promise.race([
        executePython(code, params),
        new Promise((_, reject) => 
            setTimeout(() => reject(new Error("Execution timeout – infinite loop detected")), timeoutMs)
        )
    ]);
};
