/**
 * Logic Lens Local Mentor Service
 * 100% Offline Socratic Guidance
 */

import { generateHint } from '../engines/HintEngine';
import { matchRequirement } from './PatternEngine';

const ERROR_EXPLANATIONS = {
    'indentation': {
        reason: "Python uses indentation (blank space at the start of a line) to group code together.",
        fix: "Ensure all lines inside this block (like under a 'def' or 'if') have exactly 4 spaces."
    },
    'missing_colon': {
        reason: "In Python, a colon (:) is like a 'doorway'. It tells the computer that a new block of code starts on the next line.",
        fix: "Add a ':' at the end of your 'def', 'if', 'for', or 'while' statement."
    },
    'syntax': {
        reason: "The code doesn't follow Python's grammar rules or contains unrecognized characters.",
        fix: "Look for typos, missing parentheses, or invalid operators like '.=' or '++'."
    }
};

const CONCEPT_WIKI = {
    'def': "The 'def' keyword is used to create a function. It's like writing a recipe that you can use later.",
    'return': "The 'return' keyword tells a function to send a specific result back to whoever called it.",
    'if': "The 'if' statement allows your code to make decisions based on whether something is True or False.",
    'for': "A 'for' loop is used to repeat an action for every item in a list or sequence.",
    'print': "The 'print()' function displays information in the Logic Console so you can see what's happening."
};

export const getLocalMentorResponse = (code, query, errors, activePattern) => {
    const q = query.toLowerCase();

    // Problem 4 Fix: Always check for syntax errors first
    if (errors.length > 0) {
        const err = errors[0];
        const explanation = ERROR_EXPLANATIONS[err.type] || { reason: err.message, fix: "Check the syntax of this line." };
        
        // If the user asks about errors, or even if they don't, prioritize the error if it's there
        if (q.includes("wrong") || q.includes("error") || q.includes("fix") || q.includes("help")) {
            return `I see an issue on line ${err.line}: ${err.message}. ${explanation.reason}\n\nTry fixing: ${explanation.fix}`;
        }
        
        // If they ask something else but have an error, nudge them
        return `Before we look at that, I notice an error on line ${err.line}. Python can't run your code until that's fixed. It says: "${err.message}"`;
    }

    // 1. Out-of-Box Handling
    if (!q.includes('code') && !q.includes('fix') && !q.includes('why') && !q.includes('error') && !q.includes('how') && !q.includes('what') && !q.includes('line')) {
        if (!q.match(/(def|if|for|while|return|print|syntax|indent|colon)/)) {
            return "I focus only on your code. Ask me about fixing errors, understanding syntax, or improving logic.";
        }
    }

    // 2. "What's wrong with my code?" (Now we know there are no errors)
    if (q.includes("wrong") || q.includes("error")) {
        return "Your syntax is optimal! The structure is clean. Focus on implementing the logic for your mission.";
    }

    // 3. "How do I fix line X?"
    const lineMatch = q.match(/line (\d+)/);
    if (lineMatch) {
        const lineNum = parseInt(lineMatch[1]);
        const errAtLine = errors.find(e => e.line === lineNum);
        if (errAtLine) {
            return `Line ${lineNum} is missing something. ${generateHint(errAtLine, 'local_escalation')}`;
        }
        return `Line ${lineNum} looks syntactically correct. Ensure it contributes to the logic of your mission.`;
    }

    // 4. "What does [X] do?"
    for (const [keyword, explanation] of Object.entries(CONCEPT_WIKI)) {
        if (q.includes(keyword)) {
            return explanation;
        }
    }

    // 5. "Show me an example"
    if (q.includes("example") || q.includes("pattern")) {
        if (activePattern) {
            if (activePattern.dynamic) {
                return "Since this is a custom mission, you should start with a function: \ndef solve_problem():\n    # Your logic\n    return result";
            }
            return `For the "${activePattern.title}" mission, the structure should look like this:\n\ndef ${activePattern.id}(params):\n    # Your logic here\n    return result`;
        }
        return "Choose a mission in Mission Control first, and I can show you the structural pattern.";
    }

    // 6. Generic Fallback
    if (activePattern && !code.includes('return') && !activePattern.dynamic) {
        return `You're on the right track with the "${activePattern.title}" mission, but your function needs to 'return' a result to complete the goal.`;
    }

    return "Your code structure looks good! Try running 'Execute Logic' (or enable Auto-Compile) to see if your output matches your goal.";
};
